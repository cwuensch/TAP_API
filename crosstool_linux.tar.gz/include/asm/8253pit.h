/*
 * 8253/8254 Programmable Interval Timer
 */

#ifndef _8253PIT_H
#define _8253PIT_H

#define PIT_TICK_RATE 	1193182UL

#endif
