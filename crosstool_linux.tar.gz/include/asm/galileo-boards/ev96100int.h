/*
 *
 */
#ifndef _MIPS_EV96100INT_H
#define _MIPS_EV96100INT_H

#define EV96100INT_UART_0    6     /* IP 6 */
#define EV96100INT_TIMER     7     /* IP 7 */

extern void ev96100int_init(void);

#endif /* !(_MIPS_EV96100_H) */
