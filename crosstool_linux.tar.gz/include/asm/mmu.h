#ifndef __ASM_MMU_H
#define __ASM_MMU_H

typedef unsigned long mm_context_t[NR_CPUS];

#endif /* __ASM_MMU_H */
