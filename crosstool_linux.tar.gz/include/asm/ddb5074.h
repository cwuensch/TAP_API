/*
 *  include/asm-mips/ddb5074.h -- NEC DDB Vrc-5074 definitions
 *
 *  Copyright (C) 2000 Geert Uytterhoeven <geert@sonycom.com>
 *                     Sony Software Development Center Europe (SDCE), Brussels
 */

extern void ddb5074_led_hex(int hex);
extern void ddb5074_led_d2(int on);
extern void ddb5074_led_d3(int on);

